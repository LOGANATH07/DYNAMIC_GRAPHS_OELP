Instructions to execute the file

.\<compiled file> <inputfile>


Output format:
shortest distance from the starting vertex to all the other vertices