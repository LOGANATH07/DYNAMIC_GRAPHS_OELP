Instructions to execute the file

.\<compiled file> congress.edgelist 475 13289


Output format:
shortest distance from the starting vertex to all the other vertices