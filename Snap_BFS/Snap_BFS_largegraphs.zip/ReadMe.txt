Instructions to execute the file

.\<compiled file> congress.edgelist 475 13289
.\<compiled file> facebook_combined 4039 88234
.\<compiled file> email-Eu-core 1005 25571


Output format:
shortest distance from the starting vertex to all the other vertices